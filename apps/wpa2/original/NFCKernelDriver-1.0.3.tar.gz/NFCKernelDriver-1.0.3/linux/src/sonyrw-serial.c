/*-----------------------------------------------------------------------------
	Name     : sonyrw-serial.c
	Function : USB-Serial Driver for Sony Reader/Writer
	Designer : ueno
	Editor   : ueno
	Revision : $Id: sonyrw-serial.c,v 1.1.1.1 2005/10/05 04:04:56 ueno Exp $

//   Redistribution and use in source and binary forms, with or without
//   modification, are permitted provided that the following conditions
//   are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in
//       the documentation and/or other materials provided with the
//       distribution.
//     * Neither the name of Sony Corporation nor the names of its
//       contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.
//
//   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
//   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
------------------------------------------------------------------------------*/

#include <linux/version.h>
#include <linux/autoconf.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/signal.h>
#include <linux/errno.h>
#include <linux/poll.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/fcntl.h>
#include <linux/tty.h>
#include <linux/tty_driver.h>
#include <linux/tty_flip.h>
#include <linux/module.h>
#include <linux/spinlock.h>
#include <linux/usb.h>
#include <linux/serial.h>

#ifdef CONFIG_USB_SERIAL_DEBUG
	static int debug = 1;
#else
	static int debug;
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
#include "usb/serial/usb-serial.h"
#else
#include "linux/usb/serial.h"
#endif

#include "sonyrw-serial.h"

/* MODULE_PARM(debug, "i"); */
/* MODULE_PARM_DESC(debug, "Debug enabled or not"); */

/*
 * Version Information
 */
#define DRIVER_VERSION	"v1.0.3"
#define DRIVER_AUTHOR	"Masatoshi Ueno <Masayoshi.Ueno@jp.sony.com>"
#define DRIVER_DESC	"Sony Near Field Communication Driver"

static __devinitdata struct usb_device_id id_table [] = {
	{ USB_DEVICE(SONYRW_VID,    SONYRW_PID   ) },
	{ USB_DEVICE(NXPRW_VID,     NXPRW_PID    ) },
	{ }						/* Terminating entry */
};

MODULE_DEVICE_TABLE (usb, id_table);

static struct usb_driver sonyrw_driver = {
	.name =         "sonyrw",
	.probe =        usb_serial_probe,
	.disconnect =   usb_serial_disconnect,
	.id_table =     id_table,
};
                                                                                                  


/* function prototypes for sonyrw */
static int  sonyrw_startup	(struct usb_serial *serial);
static void sonyrw_shutdown	(struct usb_serial *serial);
static int  sonyrw_open		(struct usb_serial_port *port, struct file *filp);
static void sonyrw_close		(struct usb_serial_port *port, struct file *filp);
static int  sonyrw_write		(struct usb_serial_port *port, const unsigned char *buf, int count);
static void sonyrw_read_bulk_callback(struct urb *urb, struct pt_regs *regs);
static void sonyrw_set_termios(struct usb_serial_port *port, struct termios * old);


#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
static struct usb_serial_device_type sonyrw_device = {
	.owner					= THIS_MODULE,
	.name					= "Sony NFC",
#else
static struct usb_serial_driver sonyrw_device = {
	.description			= "Sony NFC",
#endif
	.id_table				= id_table,
	.num_interrupt_in		= NUM_DONT_CARE,
	.num_bulk_in			= 1,
	.num_bulk_out			= 1,
	.num_ports				= 1,
	.open					= sonyrw_open,
	.close					= sonyrw_close,
	.set_termios			= sonyrw_set_termios,
	.write					= sonyrw_write,
	.attach					= sonyrw_startup,
	.shutdown				= sonyrw_shutdown,
};



/**
 * default urb timeout
 */
#define SONYRW_TIMEOUT ( HZ * 5 )



/**
 *
 *
 *	SONYRW specific functions
 *	
 *
 */


/**
 *	SONYRW Open command
 *	This routine is called when a ttyUSB port is opened.
 */
static int sonyrw_open(struct usb_serial_port *port, struct file *filp)
{
	struct termios		tmp_termios;
	struct usb_serial	*serial = port->serial;
	int					result = -ENOENT;

	/* Check the sanity of a pointer */
	if (!port) {
		return -ENODEV;
	}

	dbg("%s - port %d\n", __FUNCTION__, port->number);

	/* Terminal setting ( dummy ) */
	*(port->tty->termios) = tty_std_termios;

	port->tty->termios->c_cflag = B115200 | CS8 | CREAD | CLOCAL;
	sonyrw_set_termios(port, &tmp_termios);

	/* Start reading from the device */
	port->write_urb->dev = serial->dev;

	/* if we have a bulk interrupt, start reading from it */
	if (serial->num_bulk_in) {
		/* Start reading from the device */
		usb_fill_bulk_urb(	port->read_urb, 
							serial->dev,
							usb_rcvbulkpipe(serial->dev, port->bulk_in_endpointAddress),
							port->read_urb->transfer_buffer, 
							port->read_urb->transfer_buffer_length,
							(usb_complete_t)sonyrw_read_bulk_callback,
							port
							);
		
		result = usb_submit_urb(port->read_urb, GFP_KERNEL);

		if (result) {
			printk("%s - failed submitting read urb, error %d\n", __FUNCTION__, result);
		}
	}

	return result;
}




/**
 *	SONYRW Close
 *	This routine is called when a ttyUSB port is closed.
 */
static void sonyrw_close(struct usb_serial_port *port, struct file * filp)
{
	struct usb_serial *serial;

	/* Check the sanity of a pointer */
	if (!port) {
		printk("%s - sanity of a pointer error.\n", __FUNCTION__ );
		return;
	}

	dbg("%s - port %d\n", __FUNCTION__, port->number);

	/* Check the sanity of a pointer */
	serial = port->serial;
	if (!serial) {
		printk("%s - serial error %d", __FUNCTION__, port->number);
		return;
	}

	/* Close the port */
	/* shutdown any bulk reads that might be going on */
	if (serial->num_bulk_out) {
		dbg("%s - shutting down write_urb", __FUNCTION__);
		usb_kill_urb(port->write_urb);
	}
	if (serial->num_bulk_in) {
		dbg("%s - shutting down read_urb", __FUNCTION__);
		usb_kill_urb(port->read_urb);
	}
}


/*
 *	SONYRW Write
 *	This routine is called when an application/library send some commands to SONYRW.
 */
static int sonyrw_write(struct usb_serial_port *port, const unsigned char *buf, int count)
{
	struct usb_serial	*serial = port->serial;
	unsigned char		*transfer_buffer;
	int					result;
	int					rlen;

	/* Check the sanity of a pointer */
	if (!port) {
		printk("%s - sanity of a pointer error.\n", __FUNCTION__);
		return -ENOENT;
	}

	/* Don't send null packet. Is it OK? */
	if (count == 0) {
		dbg("%s - write request of 0 bytes.", __FUNCTION__);
		return 0;
	}

	if (port->write_urb->status == -EINPROGRESS) {
		dbg ("%s - already writing.", __FUNCTION__);
		return 0;
	}

	/* Memory allocation for transfer buffer */
	transfer_buffer = kmalloc(count, GFP_KERNEL);

	if (!transfer_buffer) {
		printk("%s - kmalloc(%d) failed.\n", __FUNCTION__, count);
	}
	else {
		/* Memory copy from serial buffer to transfer buffer */
		memcpy(transfer_buffer, buf, count);

		result = usb_bulk_msg(	serial->dev,
								usb_sndbulkpipe(serial->dev, port->bulk_out_endpointAddress),
								transfer_buffer,
								count,
								&rlen,
								SONYRW_TIMEOUT
								);

		/* When 64 bytes data transfer, the device doesn't respond. */
		/* To avoid the issue, 0 length data transfer just in case. */
		if (0 == (count % port->bulk_out_size)) {
			result += usb_bulk_msg(	serial->dev,
									usb_sndbulkpipe(serial->dev, port->bulk_out_endpointAddress),
									NULL,
									0,
									0,
									SONYRW_TIMEOUT
									);
		}

		if (result) {
			printk("%s - failed submitting bulk urb, error %d\n", __FUNCTION__, result);
			rlen = -EFAULT;
		}

		kfree( transfer_buffer );
	}

	return rlen;
}

/*
 *	SONYRW Read Bulk Callback
 *	This routine is called when usb-host-controller received bulk packet commands.
 */
static void sonyrw_read_bulk_callback(struct urb *urb, struct pt_regs *regs)
{
	struct usb_serial_port *port = NULL;
	struct usb_serial *serial = NULL;
	struct tty_struct *tty = NULL;
	unsigned char *data = urb->transfer_buffer;
	int result;

	/* Check the sanity of a pointer */
	port = (struct usb_serial_port *)urb->context;
	if (!port) {
		printk("%s - sanity of a pointer error.\n", __FUNCTION__);
		return;
	}

	serial = port->serial;
	if (!serial) {
		printk("%s - bad serial pointer, exiting\n", __FUNCTION__);
		return;
	}

	tty = port->tty;
	if (tty && urb->actual_length) {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,18)
		int i;
		for (i = 0; i < urb->actual_length ; ++i) {
			if(tty->flip.count >= TTY_FLIPBUF_SIZE) {
				tty_flip_buffer_push(tty);
			}
			/* this doesn't actually push the data through unless tty->low_latency is set */
			tty_insert_flip_char(tty, data[i], 0);
		}
#else
		tty_buffer_request_room(tty, urb->actual_length);
		tty_insert_flip_string(tty, data, urb->actual_length);
#endif
		tty_flip_buffer_push(tty);
	}

	/* Continue trying to always read  */
	usb_fill_bulk_urb(	port->read_urb, 
						serial->dev, 
		      			usb_rcvbulkpipe(serial->dev, port->bulk_in_endpointAddress),
		      			port->read_urb->transfer_buffer, 
						port->read_urb->transfer_buffer_length,
		      			(usb_complete_t)sonyrw_read_bulk_callback, 
		      			port
						);

	result = usb_submit_urb(port->read_urb, GFP_KERNEL);

	if (result) {
		printk("%s - failed resubmitting read urb, error %d\n", __FUNCTION__, result);
	}

	return;
}


/*
 *	SONYRW Set Termios
 *	This routine is called when set the tty status.
 */
static void sonyrw_set_termios(struct usb_serial_port *port, struct termios *old_termios)
{
	unsigned int cflag;

	/* Check the sanity of a pointer */
	if (!port) {
		printk("%s - sanity of a pointer error.", __FUNCTION__);
		return;
	}

	dbg("%s - port %d\n", __FUNCTION__, port->number);

	/* Check tty status */
	if ((!port->tty) || (!port->tty->termios)) {
		printk("%s - no tty structures", __FUNCTION__);
		return;
	}

	cflag = port->tty->termios->c_cflag;

	/* check that they really want us to change something */
	if (old_termios) {
		if ((cflag == old_termios->c_cflag) && 
			(RELEVANT_IFLAG(port->tty->termios->c_iflag) == RELEVANT_IFLAG(old_termios->c_iflag))) {
			dbg("%s - nothing to change...", __FUNCTION__);
			return;
		}
	}

	/* Check tty flow control */
	if (I_IXOFF(port->tty)) {
		dbg("%s - XON/XOFF is enabled, XON = %2x, XOFF = %2x\n"
			, __FUNCTION__, START_CHAR(port->tty), STOP_CHAR(port->tty));
	}
	else {
		dbg("%s - XON/XOFF is disabled", __FUNCTION__);
	}

	dbg("%s - baud rate = %d", __FUNCTION__, tty_get_baud_rate(port->tty));
}

/*
 *	SONYRW Startup
 *	This routine is called when the SONYRW is connected to USB port.
 */
static int sonyrw_startup (struct usb_serial *serial)
{
	return 0;
}


/*
 *	SONYRW Shutdown
 *	This routine is called when the SONYRW is disconnected to USB port.
 */
static void sonyrw_shutdown (struct usb_serial *serial)
{
	dbg("%s\n", __FUNCTION__);
}


/*
 *	SONYRW Init
 */
static int __init sonyrw_init(void)
{
	int ret;

	ret = usb_serial_register(&sonyrw_device);
	if (ret) {
		return ret;
	}

	ret = usb_register(&sonyrw_driver);
	if (ret) {
		usb_serial_deregister(&sonyrw_device);
		return ret;
	}

	info(DRIVER_DESC " " DRIVER_VERSION);

	return 0;
}


/*
 *	SONYRW Exit
 */
static void __exit sonyrw_exit (void)
{
	usb_deregister(&sonyrw_driver);
	usb_serial_deregister(&sonyrw_device);
}

module_init(sonyrw_init);
module_exit(sonyrw_exit);

MODULE_AUTHOR( DRIVER_AUTHOR );
MODULE_DESCRIPTION( DRIVER_DESC );
MODULE_LICENSE( "Dual BSD/GPL" );

/**
 * End of file.
 **/

