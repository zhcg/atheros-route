/*------------------------------------------------------------------------------
	Name     : sonyrw-serial.h
	Function : USB-Serial Driver for Sony Reader/Writer
	Designer : ueno
	Editor   : ueno
	Revision : $Id: sonyrw-serial.h,v 1.1.1.1 2005/10/05 04:04:56 ueno Exp $

//   Redistribution and use in source and binary forms, with or without
//   modification, are permitted provided that the following conditions
//   are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in
//       the documentation and/or other materials provided with the
//       distribution.
//     * Neither the name of Sony Corporation nor the names of its
//       contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.
//
//   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
//   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
------------------------------------------------------------------------------*/


/* Vendor ID and Product ID */
#define SONYRW_VID	0x054C	/* Vendor Id (Sony) */
#define SONYRW_PID	0x0193	/* Product Id of SONYRW */
#define NXPRW_VID 0x04CC	/* Vendor Id (NXP) */
#define NXPRW_PID 0x0531	/* Product Id of NXPRW */


/* SONYRW access */
#define SONYRW_CODE_REQUEST_TYPE	0x80	/* Request type for ID */
#define SONYRW_CODE_REQUEST		0x06	/* Request code for ID */

#define SONYRW_REQUEST_TYPE		0x00	/* Request type for normal command */
#define SONYRW_REQUEST			0x00	/* Request code for normal command */



