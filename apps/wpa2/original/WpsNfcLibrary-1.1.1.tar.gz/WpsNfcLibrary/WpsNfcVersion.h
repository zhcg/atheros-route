#define WPSNFCLIB_VERSION 65793 /* 1.1.1 */
#define LIB_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
