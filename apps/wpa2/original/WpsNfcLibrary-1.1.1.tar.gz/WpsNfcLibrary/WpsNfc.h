/**************************************************************************** 
//
//  Copyright (c) 2006 Sony Corporation. All Rights Reserved.
//
//  File Name: WpsNfc.h
//  Description: Implements NFC driver library
//
//   Redistribution and use in source and binary forms, with or without
//   modification, are permitted provided that the following conditions
//   are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in
//       the documentation and/or other materials provided with the
//       distribution.
//     * Neither the name of Sony Corporation nor the names of its
//       contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.
//
//   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
//   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****************************************************************************/

#ifndef __WPSNFC_H__
#define __WPSNFC_H__

#include "WpsNfcVersion.h"

/* WPS NFC Library Error Code */

#define WPS_NFCLIB_ERR_SUCCESS              0
#define WPS_NFCLIB_ERR_FAILURE              0xFFFFFFFF
#define WPS_NFCLIB_ERR_OUT_OF_MEMORY        0x00000001
#define WPS_NFCLIB_ERR_NOT_INITIALIZED      0x00000002
#define WPS_NFCLIB_ERR_INITIALIZED          0x00000003
#define WPS_NFCLIB_ERR_INVALID_PARAMETER    0x00000004
#define WPS_NFCLIB_ERR_DEVICE_NOT_OPENED    0x00000005
#define WPS_NFCLIB_ERR_TARGET_NOT_FOUND     0x00000006
#define WPS_NFCLIB_ERR_INVALID_FORMAT       0x00000007
#define WPS_NFCLIB_ERR_NO_DEVICE_FOUND      0x00000008
#define WPS_NFCLIB_ERR_DEVICE_NOT_FOUND     0x00000009
#define WPS_NFCLIB_ERR_DISCONNECT           0x0000000A
#define WPS_NFCLIB_ERR_TOKEN_CONNECTION     0x0000000B
#define WPS_NFCLIB_ERR_SELECT_FILE_FAILED   0x0000000C
#define WPS_NFCLIB_ERR_READ_TARGET          0x0000000D
#define WPS_NFCLIB_ERR_WRITE_TARGET         0x0000000E
#define WPS_NFCLIB_ERR_CLEAR_TARGET         0x0000000F
#define WPS_NFCLIB_ERR_RECORD_NOT_FOUND     0x00000010
#define WPS_NFCLIB_ERR_INVALID_RECORD_INDEX 0x00000011
#define WPS_NFCLIB_ERR_BUFFER_TOO_SMALL     0x00000012


#if defined (__cplusplus)
extern "C" {
#endif /* defined (__cplusplus) */

uint32 WpsNfcInit(void);
uint32 WpsNfcDeinit(void);

uint32 WpsNfcOpenDevice(const int8 * const name);
uint32 WpsNfcCloseDevice(void);

uint32 WpsNfcTokenDiscovery(void);

/* For NFC Token Target */
uint32 WpsNfcReadTokenMessage(uint32 * const record_num);
uint32 WpsNfcGetRecordFromMessage(const uint32 index, int8 ** const data, uint32 * const length);

uint32 WpsNfcWriteToken(const int8 * const data, const uint32 length);

uint32 WpsNfcTokenCapacity(uint32 * const length);

uint32 WpsNfcClearToken( const int physical );

/* WpsNfcReadToken is obsolete. */
/* Use WpsNfcReadTokenMessage, WpsNfcGetRecordFromMessage instead. */
uint32 WpsNfcReadToken(int8 * const data, uint32 * const length);

/* This debug fct allocates the data buffer!! be careful */
uint32 WpsNfcRawReadToken(int8 ** const pdata, uint32 * const length);
uint32 WpsNfcRawWriteToken(const int8 * const data, const uint32 length);

#if defined (__cplusplus)
}   /* extern "C" */
#endif /* defined (__cplusplus) */

#endif /* __WPSNFC_H__ */
/* WPS NFC Library Error Code */
