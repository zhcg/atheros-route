/**************************************************************************** 
//
//  Copyright (c) 2006 Sony Corporation. All Rights Reserved.
//
//  File Name: main.c
//  Description: Implements NFC token utility
//
//   Redistribution and use in source and binary forms, with or without
//   modification, are permitted provided that the following conditions
//   are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in
//       the documentation and/or other materials provided with the
//       distribution.
//     * Neither the name of Sony Corporation nor the names of its
//       contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.
//
//   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
//   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined( __linux__ )
#include <sys/time.h>
#elif defined( CONFIG_NATIVE_WINDOWS )
#include <windows.h>
#endif /* defined( __linux__ ) */
#include "WpsNfcType.h"
#include "WpsNfc.h"
#include "memory_dump.h"

#define WPSNFC_RW_APP_VERSION	0x00010101   /* Version 1.1.1 */
#define MAJOR_VERSION( ver )	( ( ( ver ) >> 16 ) & 0x00FF )
#define MINOR_VERSION( ver )	( ( ( ver ) >> 8 ) & 0x00FF )
#define MICRO_VERSION( ver )	( ( ver ) & 0x00FF )

#define DEFAULT_SEARCH_TIME	10	/* sec */

#ifndef WPSNFCLIB_VERSION
#ifndef LIB_VERSION
#define WPSNFCLIB_VERSION 0
#define LIB_VERSION( a, b, c ) 1
#else
#define WPSNFCLIB_VERSION LIB_VERSION( 1, 0, 0 ) /* 1.0.0 */
#endif /* LIB_VERSION */
#endif /* WPSNFCLIB_VERSION */

void PrintMainMenu( void );

void SearchMenuProc( void );
void PrintSearchMenu( void );

void ReadMenuProc( void );
void PrintReadMenu( void );

void WriteMenuProc( void );
void PrintWriteMenu( void );

void FormatMenuProc( void );
void PrintFormatMenu( void );

void CapaMenuProc( void );
void PrintCapaMenu( void );

void RawReadMenuProc( void );
void PrintRawReadMenu( void );

#if WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 )
void RawWriteMenuProc( void );
void PrintRawWriteMenu( void );
#endif /* WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 ) */

uint32 GetCurTime( void ) {
#if defined( __linux__ )
    struct timeval now;
    gettimeofday( &now, NULL );
    return ( now.tv_sec * 1000 + ( now.tv_usec / 1000 ) );
#elif defined( CONFIG_NATIVE_WINDOWS )
	return GetTickCount();
#endif /* defined( __linux__ ) */
}

int main( int argc, char * argv[] ) {
	int isQuit = 0;
	char inp[0x100];
	uint32 err;

	printf ( "\n**************************************************************************************\n" );
	printf ( "********** NFC Reader/Writer Application for Wifi - Simple Config NFC Token **********\n" );
	printf ( "**********                         Version %2d.%2d.%2d                         **********\n", 
			 MAJOR_VERSION( WPSNFC_RW_APP_VERSION ), MINOR_VERSION( WPSNFC_RW_APP_VERSION ), MICRO_VERSION( WPSNFC_RW_APP_VERSION ) );
	printf ( "**************************************************************************************\n\n" );

	do {
		if ( 2 != argc ) {
			printf ( "NFCTokenRW [NFC Device Path]\n" );
			printf ( "example : NFCTokenRW /dev/ttyUSB0\n\n" );
			break;
		}

		if ( WPS_NFCLIB_ERR_SUCCESS != ( err = WpsNfcInit() ) ) {
			fprintf( stderr, "Wps NFC Library Init Error [0x%08lX]\n\n", err );
			break;
		}

		if ( WPS_NFCLIB_ERR_SUCCESS != ( err = WpsNfcOpenDevice( ( int8 * )argv[1] ) ) ) {
			fprintf( stderr, "NFC Device Open Error (%s) [0x%08lX]\n\n", argv[1], err );
			( void )WpsNfcDeinit();
			break;
		}

		do {
			PrintMainMenu();

			fgets( inp, sizeof( inp ), stdin );
			switch( inp[0] ) {
				case '0':	/* Quit */
					fprintf( stderr, "Shutdown...\n" );
					isQuit = 1;
					break;

				case '1':	/* Search */
					SearchMenuProc();
					break;

				case '2':	/* Read */
					ReadMenuProc();
					break;

				case '3':	/* Write */
					WriteMenuProc();
					break;

				case '4':	/* Format */
					FormatMenuProc();
					break;

				case '5': 	/* Capacity */
					CapaMenuProc();
					break;

				case '6':	/* Raw Read Token */
					RawReadMenuProc();
					break;

#if WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 )
				case '7':	/* Raw Write Token */
					RawWriteMenuProc();
					break;
#endif /* WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 ) */

				default:
					fprintf( stderr, "Invalid Input Value\n\n" );
					break;
			}	/* switch */
		} while ( !isQuit );

		if ( WPS_NFCLIB_ERR_SUCCESS != ( err = WpsNfcCloseDevice() ) ) {
			fprintf( stderr, "\nNFC Device Close Error (%s) [0x%08lX]\n\n", argv[1], err );
		}

		if ( WPS_NFCLIB_ERR_SUCCESS != ( err = WpsNfcDeinit() ) ) {
			fprintf( stderr, "Wps NFC Library Deinit Error [0x%08lX]\n\n", err );
		}
	} while ( 0 );

	fprintf( stdout, "\nPush enter key to quit...\n" );
	fgetc( stdin );

	return 0;
}

void PrintMainMenu( void ) {
	fprintf( stdout, "\n_/_/_/_/_/_/_/_/_/_/ MENU _/_/_/_/_/_/_/_/_/_/_/_/\n" );
	fprintf( stdout, " 0 : Quit\n" );
	fprintf( stdout, " 1 : Search NFC Token\n" );
	fprintf( stdout, " 2 : Read NFC Token\n" );
	fprintf( stdout, " 3 : Write NFC Token\n" );
	fprintf( stdout, " 4 : Format NFC Token\n" );
	fprintf( stdout, " 5 : TLV Capacity of NFC Token\n" );
	fprintf( stdout, " 6 : Raw Read NFC Token\n" );
#if WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 )
	fprintf( stdout, " 7 : Raw Write NFC Token\n" );
#endif /* WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 ) */
	fprintf( stdout, "Enter : " );
	return;
}

void SearchMenuProc( void ) {
	uint32 res;
	char inp[0x100];
	uint32 searchTime;
	uint32 sta, cur;

	PrintSearchMenu();
	fgets( inp, sizeof( inp ), stdin );
	searchTime = strtoul( inp, 0, 10 );
	if ( !searchTime )
		searchTime = DEFAULT_SEARCH_TIME;

	fprintf( stdout, "\tPlace NFC Token Now \n" );

	sta = GetCurTime();
	do {
		res = WpsNfcTokenDiscovery();
		cur = GetCurTime();
	} while ( ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res ) && ( searchTime > ( ( cur - sta ) / 1000 ) ) );

	if ( WPS_NFCLIB_ERR_SUCCESS == res )
		fprintf( stderr, "\t[ Found NFC Token !! ]\n" );
	else if ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res )
		fprintf( stderr, "\t[ Not Found NFC Token .. ]\n" );
	else
		fprintf( stderr, "\t[ Failed Search NFC Token !! [0x%08lX] ]\n", res );

	return;
}

void PrintSearchMenu( void ) {
	fprintf( stdout, "\tInput Search Time (sec) [%d] : ", DEFAULT_SEARCH_TIME );
}

void ReadMenuProc( void ) {
	uint32 res;
	char inp[0x100];
	uint32 searchTime;
	uint32 sta, cur;
#if WPSNFCLIB_VERSION < LIB_VERSION( 1, 1, 1 )
	uint8 buf[0x1000];
#else /* WPSNFCLIB_VERSION < LIB_VERSION( 1, 1, 1 ) */
	uint8 *buf = 0;
#endif /* WPSNFCLIB_VERSION < LIB_VERSION( 1, 1, 1 ) */
	uint32 len;
	FILE * fp;
	uint32 record_num = 0;
	uint32 index;

	PrintReadMenu();

	searchTime = DEFAULT_SEARCH_TIME;
	fprintf( stdout, "\tPlace NFC Token Now \n" );

	sta = GetCurTime();
	do {
		res = WpsNfcTokenDiscovery();
		if ( WPS_NFCLIB_ERR_SUCCESS == res ) {
#if WPSNFCLIB_VERSION < LIB_VERSION( 1, 1, 1 )
			len = 0;
			res = WpsNfcReadToken( ( int8 * )buf, &len );
#else /* WPSNFCLIB_VERSION < LIB_VERSION( 1, 1, 1 ) */
			res = WpsNfcReadTokenMessage( &record_num );
#endif /* WPSNFCLIB_VERSION < LIB_VERSION( 1, 1, 1 ) */
		}
		cur = GetCurTime();
	} while ( ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res ) && ( searchTime > ( ( cur - sta ) / 1000 ) ) );

	if ( WPS_NFCLIB_ERR_SUCCESS == res ) {
		fprintf( stderr, "\t[ Succeded Read NFC Token !! ]\n" );

#if WPSNFCLIB_VERSION < LIB_VERSION( 1, 1, 1 )
		record_num = 1;
#else /* WPSNFCLIB_VERSION < LIB_VERSION( 1, 1, 1 ) */
		if ( record_num )
			fprintf( stderr, "\t\t[ %ld WPS Record%s Found !! ]\n", record_num, ( 1 < record_num ) ? "s" : "" );
		else
			fprintf( stderr, "\t\t[ Cannot Find WPS Record !! ]\n" );
#endif /* WPSNFCLIB_VERSION < LIB_VERSION( 1, 1, 1 ) */
		for ( index = 0; index < record_num; index++ ) {
#if WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 )
			len = 0;
			if ( WPS_NFCLIB_ERR_SUCCESS == WpsNfcGetRecordFromMessage( index, (int8 **)&buf, &len ) ) {
				fprintf( stderr, "\t\t[ Succeded Read Record !! : index = %ld ]\n", index );
#endif /* WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 ) */
				memory_dump( buf, len, 16 );

				fprintf( stderr, "\t\tInput File Name to Save Data in NFC Token : " );
				fgets( inp, sizeof( inp ), stdin );
				if ( 0 != strchr( inp, '\n' ) )
					*strchr( inp, '\n' ) = 0;

				do {
					if ( 0 != strlen( inp ) ) {
						fp = fopen( inp, "wb" );
						if ( !fp ) {
							fprintf( stderr, "\t\t\t[ Cannot File Open !! ]\n" );
							break;
						}

						fwrite( buf, sizeof( uint8 ), len, fp );

						fclose( fp );

						fprintf( stderr, "\t\t\t[ Succeded Save Data !! ]\n" );
					}
				} while ( 0 );
#if WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 )
			} else
				fprintf( stderr, "\t\t[ Failed Read WPS Record !! : index = %ld ]\n", index );

			if ( buf ) {
				free( buf );
				buf = 0;
			}
#endif /* WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 ) */
		} /* for */
	} else if ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res )
		fprintf( stderr, "\t[ Not Found NFC Token .. ]\n" );
	else
		fprintf( stderr, "\t[ Failed Read NFC Token !! [0x%08lX] ]\n", res );

	return;
}

void PrintReadMenu( void ) {
	fprintf( stdout, "\n\t_/_/_/_/_/_/_/_/_/_/ READ TOKEN _/_/_/_/_/_/_/_/_/_/_/_/\n" );
	return;
}

void WriteMenuProc( void ) {
	uint32 res;
	char inp[0x100];
	uint32 searchTime;
	uint32 sta, cur;
	uint8 buf[0x1000];
	uint32 len = 0;
	FILE * fp;

	PrintWriteMenu();
	fgets( inp, sizeof( inp ), stdin );
	if ( 0 != strchr( inp, '\n' ) )
		*strchr( inp, '\n' ) = 0;

	fp = fopen( inp, "rb" );
	if ( !fp ) {
		fprintf( stderr, "\t[ No Such File Exist !! : %s ]\n", inp );
		return;
	}

	searchTime = DEFAULT_SEARCH_TIME;
	fprintf( stdout, "\tPlace NFC Token Now \n" );

	sta = GetCurTime();
	do {
		res = WpsNfcTokenDiscovery();
		if ( WPS_NFCLIB_ERR_SUCCESS == res ) {
			len = fread( buf, 1, sizeof( buf ), fp );
			res = WpsNfcWriteToken( ( int8 * )buf, len );
		}
		cur = GetCurTime();
	} while ( ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res ) && ( searchTime > ( ( cur - sta ) / 1000 ) ) );

	if ( WPS_NFCLIB_ERR_SUCCESS == res ) {
		fprintf( stderr, "\t[ Succeded Write NFC Token !! : %lu bytes ]\n", len );
		memory_dump( buf, len, 16 );
	} else if ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res )
		fprintf( stderr, "\t[ Not Found NFC Token .. ]\n" );
	else
		fprintf( stderr, "\t[ Failed Write NFC Token !! [0x%08lX] ]\n", res );

	if ( fp ) {
		fclose( fp );
		fp = 0;
	}

	return;
}

void PrintWriteMenu( void ) {
	fprintf( stdout, "\n\t_/_/_/_/_/_/_/_/_/_/ WRITE TOKEN _/_/_/_/_/_/_/_/_/_/_/_/\n" );
	fprintf( stdout, "\tInput Write Data File : " );
	return;
}

void CapaMenuProc( void ){
	uint32 res;
	uint32 searchTime;
	uint32 sta, cur;
	uint32 len = 0;

	PrintCapaMenu();

	searchTime = DEFAULT_SEARCH_TIME;
	fprintf( stdout, "\tPlace NFC Token Now \n" );

	sta = GetCurTime();
	do {
		res = WpsNfcTokenDiscovery();
		if ( WPS_NFCLIB_ERR_SUCCESS == res )
			res = WpsNfcTokenCapacity( &len );
		cur = GetCurTime();
	} while ( ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res ) && ( searchTime > ( ( cur - sta ) / 1000 ) ) );

	if ( WPS_NFCLIB_ERR_SUCCESS == res ) {
		fprintf( stdout, "\t[ Succeded Read NFC Token Capacity !! ]\n" );
		fprintf( stdout, "\tTotal Capacity for Wi-Fi Protected Setup TLV: %u\n", ( unsigned int ) len );
	} else if ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res )
		fprintf( stderr, "\t[ Not Found NFC Token .. ]\n" );
	else
		fprintf( stderr, "\t[ Failed Write NFC Token !! [0x%08lX] ]\n", res );

	return;
}

void PrintCapaMenu( void ) {
	fprintf( stdout, "\n\t_/_/_/_/_/_/_/_/_/_/ CAPACITY TOKEN _/_/_/_/_/_/_/_/_/_/_/_/\n" );
	return;
}

void FormatMenuProc( void ) {
	uint32 res;
	char inp[0x100];
	uint32 searchTime;
	uint32 sta, cur;
	int isInput;
	int physical;

	do {
		PrintFormatMenu();
		fgets( inp, sizeof( inp ), stdin );

		isInput = 0;
		switch ( inp[0] ) {
			case '0':	/* Quit */
				return;
			case '1':	/* Physical Format */
				physical = 1;
				isInput = 1;
				break;
			case '2':	/* Logical Format */
				physical = 0;
				isInput = 1;
				break;
			default:
				fprintf( stderr, "Invalid Input Value\n\n" );
				break;
		}
	} while ( !isInput );

	searchTime = DEFAULT_SEARCH_TIME;
	fprintf( stdout, "\tPlace NFC Token Now \n" );

	sta = GetCurTime();
	do {
		res = WpsNfcTokenDiscovery();
		if ( WPS_NFCLIB_ERR_SUCCESS == res )
			res = WpsNfcClearToken( physical );
		cur = GetCurTime();
	} while ( ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res ) && ( searchTime > ( ( cur - sta ) / 1000 ) ) );

	if ( WPS_NFCLIB_ERR_SUCCESS == res )
		fprintf( stderr, "\t[ Succeded %s Format NFC Token !! ]\n", ( 1 == physical )?"Physical":"Logical" );
	else if ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res )
		fprintf( stderr, "\t[ Not Found NFC Token .. ]\n" );
	else
		fprintf( stderr, "\t[ Failed %s Format NFC Token !! [0x%08lX] ]\n", ( 1 == physical )?"Physical":"Logical", res );

	return;
}

void PrintFormatMenu( void ) {
	fprintf( stdout, "\n\t_/_/_/_/_/_/_/_/_/_/ FORMAT TOKEN _/_/_/_/_/_/_/_/_/_/_/_/\n" );
	fprintf( stdout, "\t 0 : Quit\n" );
	fprintf( stdout, "\t 1 : Physical Format\n" );
	fprintf( stdout, "\t 2 : Logical Format\n" );
	fprintf( stdout, "\tEnter : " );
	return;
}

void RawReadMenuProc( void ) {
	uint32 res;
	char inp[0x100];
	uint32 searchTime;
	uint32 sta, cur;
	uint8 *buf = 0;
	uint32 len;
	FILE * fp;

	PrintRawReadMenu();

	searchTime = DEFAULT_SEARCH_TIME;
	fprintf( stdout, "\tPlace NFC Token Now \n" );

	sta = GetCurTime();
	do {
		res = WpsNfcTokenDiscovery();
		if ( WPS_NFCLIB_ERR_SUCCESS == res ) {
			len = 0;
			res = WpsNfcRawReadToken( ( int8 ** )&buf, &len );
		}
		cur = GetCurTime();
	} while ( ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res ) && ( searchTime > ( ( cur - sta ) / 1000 ) ) );

	if ( WPS_NFCLIB_ERR_SUCCESS == res ) {
		fprintf( stderr, "\t[ Succeded Read NFC Token !! : %lu bytes ]\n", len );
		memory_dump( buf, len, 16 );

		fprintf( stderr, "\tInput File Name to Save Data in NFC Token : " );
		fgets( inp, sizeof( inp ), stdin );
		if ( 0 != strchr( inp, '\n' ) )
			*strchr( inp, '\n' ) = 0;

		if ( 0 != strlen( inp ) ) {
			fp = fopen( inp, "wb" );
			if ( !fp ) {
				fprintf( stderr, "\t[ Cannot File Open !! ]\n" );
				return;
			}

			fwrite( buf, sizeof( uint8 ), len, fp );

			fclose( fp );

			fprintf( stderr, "\t[ Succeded Save Data !! ]\n" );
		}
	} else if ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res )
		fprintf( stderr, "\t[ Not Found NFC Token .. ]\n" );
	else
		fprintf( stderr, "\t[ Failed Read NFC Token !! [0x%08lX] ]\n", res );

	if ( buf )
		free( buf );

	return;
}

void PrintRawReadMenu( void ) {
	fprintf( stdout, "\n\t_/_/_/_/_/_/_/_/_/_/ RAW READ TOKEN _/_/_/_/_/_/_/_/_/_/_/_/\n" );
	return;
}

#if WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 )
void RawWriteMenuProc( void ) {
	uint32 res;
	char inp[0x100];
	uint32 searchTime;
	uint32 sta, cur;
	uint8 buf[0x1000];
	uint32 len = 0;
	FILE * fp;

	PrintRawWriteMenu();
	fgets( inp, sizeof( inp ), stdin );
	if ( 0 != strchr( inp, '\n' ) )
		*strchr( inp, '\n' ) = 0;

	fp = fopen( inp, "rb" );
	if ( !fp ) {
		fprintf( stderr, "\t[ No Such File Exist !! : %s ]\n", inp );
		return;
	}

	searchTime = DEFAULT_SEARCH_TIME;
	fprintf( stdout, "\tPlace NFC Token Now \n" );

	sta = GetCurTime();
	do {
		res = WpsNfcTokenDiscovery();
		if ( WPS_NFCLIB_ERR_SUCCESS == res ) {
			len = fread( buf, 1, sizeof( buf ), fp );
			res = WpsNfcRawWriteToken( ( int8 * )buf, len );
		}
		cur = GetCurTime();
	} while ( ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res ) && ( searchTime > ( ( cur - sta ) / 1000 ) ) );

	if ( WPS_NFCLIB_ERR_SUCCESS == res ) {
		fprintf( stderr, "\t[ Succeded Write NFC Token !! : %lu bytes ]\n", len );
		memory_dump( buf, len, 16 );
	} else if ( WPS_NFCLIB_ERR_TARGET_NOT_FOUND == res )
		fprintf( stderr, "\t[ Not Found NFC Token .. ]\n" );
	else
		fprintf( stderr, "\t[ Failed Write NFC Token !! [0x%08lX] ]\n", res );

	if ( fp ) {
		fclose( fp );
		fp = 0;
	}

	return;
}

void PrintRawWriteMenu( void ) {
	fprintf( stdout, "\n\t_/_/_/_/_/_/_/_/_/_/ RAW WRITE TOKEN _/_/_/_/_/_/_/_/_/_/_/_/\n" );
	fprintf( stdout, "\tInput Write Data File : " );
	return;
}

#endif /* WPSNFCLIB_VERSION >= LIB_VERSION( 1, 1, 1 ) */
